


//======================== Network and Force Layout =========================


var width = 400,
    height = 400;
var B, L;
var N = Math.pow(B,L);
var opacity = 0.8;
var d_opac = 0.6;

var started = false;

var color;
var d_color=0.92;

var nodes = [],
    links = [];

var radius = d3.scale.sqrt()
                .domain([0,5])
                .range([1,3]);
                //.range([2,5]);
//var thickness = d3.scale.linear()
//                .

var pause_for_new_connection = 2000;    

var force = d3.layout.force()
    .nodes(nodes)
    .links(links)
    .charge(-15)
    .linkDistance(10)
    .size([width, height])
    .on("tick", tick);

var network_svg = d3.select("#network")//.append("network_svg")
    .attr("width", width)
    .attr("height", height);

var node = network_svg.selectAll(".node"),
    link = network_svg.selectAll(".link");

var graph = {};
var initial_nodes = [];
var initial_links = [];
//var xi = 0.55

d3.json("test.json", function(error, json) {
  graph = json; 
  

  B = graph.dummy.graph[1][1];
  L = graph.dummy.graph[2][1];
  //console.log(B);
  if (B==4){
        color = d3.scale.category20c();
  } else {
        color = d3.scale.category10();
  }
  nodes.push.apply(nodes,graph.dummy.nodes);
  links.push.apply(links,graph.dummy.links);

  link = link.data(force.links(), function(d) { return d.label;})
  link.enter()
        .insert("line", ".line")
        .attr("class", "link");
  link
        .attr("x1", function(d) { return d.source.x; })
        .attr("y1", function(d) { return d.source.y; })
        .attr("x2", function(d) { return d.target.x; })
        .attr("y2", function(d) { return d.target.y; });
  link.exit()
        .remove();

  node = node.data(force.nodes(), function(d) { return d.id; });
  node.enter().append("circle")
       .attr("class","node")
       .attr("fill", function(d) { 
                //group_sub_level = Math.floor((d.id) / B) % B - Math.floor(B/2-1);
                //var c = d3.rgb(color(d.group));
                //c.r = Math.floor(c.r*Math.pow(d_color,group_sub_level));
                //c.g = Math.floor(c.g*Math.pow(d_color,group_sub_level));
                //c.b = Math.floor(c.b*Math.pow(d_color,group_sub_level));
                group_sub_level = Math.floor((d.id) / B) % B;
                var c = d3.hsl(color(d.group));
                c.l = c.l*Math.pow(d_color,-group_sub_level);
                return c.toString(); 
            })
        .attr("r", 5);
  node.call(force.drag);

  updateNetwork();
  start_dist_and_cluster(true,true);

});

function updateNetwork() {


  force.stop();

  //document.getElementById('showxi').innerHTML = xi;

  var new_links = graph[xi].links.slice();

  var get_new_nodes = {};
  var degree = new Array(nodes.length)

  for(i=0;i<nodes.length;i++){
      degree[i]=0;
  }

  for (var i=0; i<new_links.length; i++){
      get_new_nodes[new_links[i].label] = { source: nodes[new_links[i].source],
                                            target: nodes[new_links[i].target],
                                            L: new_links[i].L
                                          };
      degree[new_links[i].source]++;
      degree[new_links[i].target]++;
  }

  for (var i=0; i<links.length; i++){
      force.alpha(0.);
      links[i].source = get_new_nodes[links[i].label].source;
      links[i].target = get_new_nodes[links[i].label].target;
      links[i].L = get_new_nodes[links[i].label].L;
  }

  var show_redist = document.getElementById("show_redistribution").checked;
  var pause = (started && show_redist )? pause_for_new_connection : 0;

  link = link.data(force.links(), function(d) { return d.label; })
  link.transition().duration(pause)
        .each("start",function(){/*force.stop();*/})
        .style("stroke-opacity",function(d){ return opacity*Math.pow(d_opac,d.L-1); })
        .style("stroke-width",function(d){ return 1.5*d.L; })
        .attr("x1", function(d) { return d.source.x; })
        .attr("y1", function(d) { return d.source.y; })
        .attr("x2", function(d) { return d.target.x; })
        .attr("y2", function(d) { return d.target.y; })
        .each("end",function(){force.start(); started=true;}); //Callback: after the end of the transition, the force module starts again.
  node.transition().duration(pause)
        .attr("r", function(d,i) { return radius(degree[i]); });

}

function tick() {
  node.attr("cx", function(d) { return d.x; })
      .attr("cy", function(d) { return d.y; })

  link.attr("x1", function(d) { return d.source.x; })
      .attr("y1", function(d) { return d.source.y; })
      .attr("x2", function(d) { return d.target.x; })
      .attr("y2", function(d) { return d.target.y; });
}




